# At the end of the labs please make sure you stop, delete following services.

1. Sagemaker notebooks: Please stop Sagemaker notebooks and once stopped delete notebook if not needed in future.

2. Sagemaker jobs: Make sure you don't Sagemaker jobs still running. Please stop any jobs that are still running after labs is done.

3. Sagemaker endpoints: Please stop and delete any Sagemaker endpoints created during the lab.

4. S3 buckets: If S3 buckets created during the lab are not needed for future, then please remove all content and delete the buckets.

5. Lambda: You can delete lambda functions if not needed in future.
