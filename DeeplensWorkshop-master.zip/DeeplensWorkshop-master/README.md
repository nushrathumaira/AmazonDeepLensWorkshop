![image](/screenshots/Slide01.jpeg)
![image](/screenshots/Slide02.jpeg)
![image](/screenshots/Slide03.jpeg)
![image](/screenshots/Slide04.jpeg)
![image](/screenshots/Slide05.jpeg)

# [Lab 1 Link](https://github.com/mahendrabairagi/DeeplensWorkshop/blob/master/lab1.md)

![image](/screenshots/Slide06.jpeg)

![image](/screenshots/Slide07.jpeg)

# [Lab 2 Link](https://github.com/mahendrabairagi/DeeplensWorkshop/blob/master/lab2.md)

![image](/screenshots/Slide08.jpeg)

# [Lab 3 Link](https://github.com/mahendrabairagi/DeeplensWorkshop/blob/master/lab3.md)

![image](/screenshots/Slide09.jpeg)

![image](/screenshots/Slide10.jpeg)

# MISC:
[Link to Deeplens troubleshooting guide](https://s3.amazonaws.com/deeplens-public/DeepLens_Troubleshooting_Guide.pdf)

[Link to Deeplens forum](https://forums.aws.amazon.com/forum.jspa?forumID=275)

[Link to Deeplens community projects](https://aws.amazon.com/deeplens/community-projects/)

